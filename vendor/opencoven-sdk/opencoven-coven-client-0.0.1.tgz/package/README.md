# @opencoven/coven-client

A constrained, owner-local Coven client. Importing the package performs
no filesystem, process, network, socket, or daemon I/O. Discovery, health, and
policy and automation capability requests happen only through explicit runtime calls.

The supported root API, pre-1.0 compatibility rules, and deprecation process
are documented in the repository
[compatibility policy](https://github.com/OpenCoven/sdk/blob/main/COMPATIBILITY.md)
and [support policy](https://github.com/OpenCoven/sdk/blob/main/SUPPORT.md).

## Shipped surface

- `discoverCovenEndpoint(options)` resolves the owner-local daemon endpoint
  only when called.
- `createDiscoveredCovenClient(...)` wraps that discovery with a `CovenClient`.
  It stays health-only by default; `automations: true` adds the read-only namespace.
- `createCovenUnixTransport(...)` and `createCovenWindowsTransport(...)`
  expose the exact reviewed built-in transports for the authenticated local
  daemon health contract.
- `createCovenClient(...)` preserves caller-supplied transports, while
  `COVEN_DAEMON_PROTOCOL` exports the exact reviewed daemon protocol string.
- `createCovenSessionPolicyClient(...)` is a separate, explicitly injected
  discovery/refusal-only policy consumer. It does not extend `CovenClient`,
  the built-in health transports, or the unified SDK client.
- `createCovenSessionPolicyUnixTransport(...)` is the opt-in real Unix policy
  transport with mandatory connected-peer security and only the two fixed
  policy routes. Windows policy transport is explicitly unsupported.
- `createCovenAutomationsClient(...)` reads the advertised Automations v1
  negotiation profile, compatibility definitions, routine health, run history
  global occurrence inspection, and receipt retrieval.
  `createCovenAutomationsUnixTransport(...)` and
  `createCovenAutomationsWindowsTransport(...)` supply authenticated owner-local
  capability GET and allowlisted read-action POST requests.
  Inject `automationsTransport` into `CovenClient` to share its operation defaults,
  or keep using the standalone client.
- `createCovenMissionsClient(...)` submits, reads, watches and cancels one
  familiar mission over the same Automations transports. See
  [Missions](#missions).

## Automations phase 1: capability discovery and diagnostic reads

### Opt into the normal client

Set `automations: true` when you discover a Coven client. On Unix, pass your
embedding runtime's reviewed native connected-peer adapter:

```ts
import {
  createDiscoveredCovenClient,
  type CovenUnixPeerIdentityAdapter,
} from '@opencoven/coven-client';
import { createOpenCovenSdk } from '@opencoven/sdk';

export async function createUnixSdk(peerIdentity: CovenUnixPeerIdentityAdapter) {
  const coven = await createDiscoveredCovenClient({
    transportSecurity: { platform: 'unix', peerIdentity },
    automations: true,
    operation: { timeoutMs: 5_000 },
  });
  return createOpenCovenSdk({ coven });
}

// With your native adapter:
// const sdk = await createUnixSdk(peerIdentity);
// const definitions = await sdk.requireCoven().requireAutomations().list();
```

On Windows, supply the reviewed native pipe-ownership adapter and discovery
options, including the native `windowsFileTrust` validator:

```ts
import {
  createDiscoveredCovenClient,
  type CovenDiscoveredWindowsClientOptions,
} from '@opencoven/coven-client';

export function createWindowsClient(options: CovenDiscoveredWindowsClientOptions) {
  return createDiscoveredCovenClient({
    ...options,
    automations: true,
    operation: { timeoutMs: 5_000, ...options.operation },
  });
}
```

Discovery runs once. Health and Automations reuse that exact endpoint, security
provider, and platform dependencies. Construction sends no health, capability,
or action request. Each later request authenticates its own connection.
The `unix`/`windows` health response-limit options still apply only to health;
Automations bounds definition inventories and compatibility run lists at 4 MiB, individual definition/run reads and event pages at 1 MiB, and paged occurrence/run histories at 256 KiB. Capabilities, health, receipts and other narrow responses retain their 16 KiB limit. Both injected-client decoding and authenticated Unix/Windows sockets enforce the same action-specific budgets. Oversized responses fail explicitly without partial results or fallback; accepted bytes still undergo the existing schema, duplicate-key, correlation and UTF-8 checks.

`client.automations` is `CovenAutomationsClient | undefined`.
`client.requireAutomations()` returns that same namespace or throws
`CovenClientError` with `code: "not_configured"` and operation `"automations"`.
It does not perform discovery or enable a transport. The umbrella SDK retains
the same client at `sdk.coven` and `sdk.requireCoven()`; there is no separate
`sdk.automations` alias.

For manual construction, inject the Automations transport explicitly:

```ts
import {
  createCovenClient,
  createCovenWindowsTransport,
  createCovenAutomationsWindowsTransport,
  type CovenDiscoveredEndpoint,
  type CovenWindowsTransportOptions,
} from '@opencoven/coven-client';

export function createWindowsClient(
  endpoint: CovenDiscoveredEndpoint,
  options: CovenWindowsTransportOptions,
) {
  return createCovenClient({
    transport: createCovenWindowsTransport(endpoint, options),
    automationsTransport: createCovenAutomationsWindowsTransport(endpoint, options),
    operation: { timeoutMs: 5_000 },
  });
}
```

Use the corresponding Unix factories for manual Unix construction. Custom
transports remain explicit trust boundaries: you must give health and Automations
the intended authority and enforce the documented authentication and limits.
The SDK never infers Automations support from a health transport.

Both namespaces inherit the normal client's timeout and observer defaults.
Per-call `timeoutMs` and `observer` override those defaults; `signal` cancels the
whole call. An Automations read shares one budget across capability negotiation,
endpoint/peer inspection, and the action response. SDK health coordination
does not poll or activate Automations.

| Surface | Unix socket | Windows named pipe |
| --- | --- | --- |
| `capabilities()` | Authenticated GET | Authenticated GET |
| `list()`, `get()`, `health()` | Allowlisted reads | Same actions and decoders |
| `runs()`, `occurrences()`, `getOccurrence()`, `getRun()` | Bounded diagnostic reads | Same actions and decoders |
| `occurrenceHistory()`, `iterateOccurrenceHistory()` | Keyset-paged diagnostic reads | Same actions and decoders |
| `runHistory()`, `iterateRunHistory()` | Keyset-paged diagnostic reads | Same actions and decoders |
| `getReceipt()` | Public/operational receipt result | Same result and privacy checks |
| `events()`, `subscribe()` | Bounded domain event pages | Same pages and cancellation |
| Normal/discovered client and `sdk.coven` | Explicit opt-in | Explicit opt-in |
| `createDraft()`, `revise()`, `activate()`, `pause()`, `disable()`, `tombstone()` | Definition and lifecycle command envelopes | Same envelope and decoder |
| TCP fallback, run/cancel/retry commands, independent receipt authentication | Not supported | Not supported |

Windows requires a current-user SID, owner-only ACL, nonempty pipe identity,
positive server PID, and process creation time before connecting. Before any
request bytes are written, the connected pipe must match all initial identity
fields and the discovered PID/creation-time freshness. Missing native adapters,
changed permissions/identity, unsafe paths, or inspection failures fail closed.
Path-only or shell-derived checks are not substitutes for native inspection.

Windows source authority is Coven v0.4.4 commit
[`4e35dd4c99013159fcee4c1ab2f183accdf7a5f8`](https://github.com/OpenCoven/coven/tree/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8):
[`daemon.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/daemon.rs#L6144-L6219)
creates an owner-only named-pipe listener and dispatches both accept paths with
`HostGuard::Disabled`, which maps to `RequestAuthority::OwnerLocalIpc`.
[`request_authority.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/request_authority.rs)
permits receipt access only through that authority, never TCP. Injected adapter
tests, including hosted Windows execution, do not certify a native adapter or
claim live-daemon conformance.

### Standalone client

Import `createCovenAutomationsClient` and `createCovenAutomationsUnixTransport`
directly from `@opencoven/coven-client`. Explicitly discover an endpoint, then
provide the same reviewed native Unix `peerIdentity` security adapter required
by the health transport:

```ts
const transport = createCovenAutomationsUnixTransport(endpoint, {
  security: { platform: 'unix', peerIdentity },
});
const automations = createCovenAutomationsClient({ transport });
const advertised = await automations.capabilities({ timeoutMs: 5_000 });
if (advertised.status === 'available') {
  console.log(advertised.variantNegotiation.supported);
}
```

The same standalone client supports definition reads:

```ts
const definitions = await automations.list(
  { includeTombstoned: false },
  { timeoutMs: 5_000 },
);
for (const routine of definitions.routines) {
  console.log(routine.id, definitions.revisionById[routine.id]);
}
const definition = await automations.get('morning', { timeoutMs: 5_000 });
if (definition.routine !== null) {
  console.log(definition.routine.status, definition.revision, definition.tombstonedAt);
}
```

These methods consume the producer's **executable compatibility** `RoutineDefinition`
(numeric `schemaVersion: 1`), not the normative rich `AutomationDefinition`.
`list()` defaults to excluding tombstones; `get()` includes a tombstoned definition
if it exists and returns `{ routine: null }` if it does not. Returned revision and
tombstone maps are checked against the returned routine IDs. Routine fields are
decoded for read interoperability, not revalidated as an executable schedule or
accepted authority.

Each read refreshes the capability advertisement and requires its exact action:
`coven.automations.definition.list.v1` or
`coven.automations.definition.get.v1`, `coven.automations.health`, `coven.automations.runs`,
`coven.automations.occurrence.list.v1`, `coven.automations.occurrence.get.v1`,
`coven.automations.run.get.v1`, or `coven.automations.receipt.get.v1`.
Missing/planned/unnegotiated profiles or
missing action names fail with `capability_unsupported` without posting an action.
Custom capability-only transports remain compatible; reads without the optional
`readDefinitions` hook fail with `unsupported_operation`.

The built-in Unix and Windows transports send only these ten allowlisted JSON actions to
`POST /api/v1/actions`. It authenticates each connection, including the separate
capability request, under one client deadline/cancellation scope. It cannot send
mutations through this hook; lifecycle commands use the separate `sendCommand`
hook described under [Lifecycle commands](#lifecycle-commands). IDs are trimmed as the producer does; the SDK
additionally rejects malformed Unicode and IDs over 4,096 UTF-8 bytes. Responses
use the existing strict 16 KiB / 16-level JSON bound (including duplicate-key and
malformed-Unicode rejection). Larger catalogs fail closed, not partially; this
producer list action has no pagination contract. Canonical action rejection
becomes `action_rejected`, while malformed/crossed responses become
`invalid_response`; daemon rejection reasons and payloads are not copied into
errors. Receipt reads use the separate typed rejection contract described below.
Capability advertisement and transport authentication do not establish
receipt authenticity or runtime authority.

Definition-read source authority is Coven
[`c56c2e2f10329c05df9273ac48914cf6b7ebb410`](https://github.com/OpenCoven/coven/tree/c56c2e2f10329c05df9273ac48914cf6b7ebb410):
[`api.rs`](https://github.com/OpenCoven/coven/blob/c56c2e2f10329c05df9273ac48914cf6b7ebb410/crates/coven-cli/src/api.rs)
routes `POST /actions` after API-version normalization;
[`control_plane.rs`](https://github.com/OpenCoven/coven/blob/c56c2e2f10329c05df9273ac48914cf6b7ebb410/crates/coven-cli/src/control_plane.rs)
advertises and dispatches these exact read actions, emits `ControlActionResponse`
with `event.kind: "automations.changed"` even for reads, and defines
`automation_list_payload` / `automation_get_payload`;
[`definition.rs`](https://github.com/OpenCoven/coven/blob/c56c2e2f10329c05df9273ac48914cf6b7ebb410/crates/coven-cli/src/automations/definition.rs)
owns the compatibility routine fields. No GET definition routes, normative
command-envelope adaptation, pagination, changefeed emission, or certification
are inferred from the schemas in `spec/coven-automations/v1`. Existing artifact
pins are unchanged. Receipt authentication,
global feed subscriptions and authority-bearing phases remain separate #80 work.

### Routine health

```ts
const { health } = await automations.health('morning', { timeoutMs: 5_000 });
console.log(health.nextDueAt, health.currentAttempt, health.quarantinedAt);
```

`health(id)` reads the exact `coven.automations.health` action (no `.v1`
suffix), returning `{ health }` from the canonical completed event payload.
All timestamp, lease, stale-reason, retry and quarantine string fields retain
explicit `null` values; `currentAttempt` is a nullable positive safe integer.
Failure/exhaustion counters are nonnegative safe integers and `maxAttempts` is
1–255. The returned `automationId` must match the trimmed requested ID.
Missing routines produce sanitized `action_rejected`, not an invented null result.
Health is store-derived diagnostic data, not execution or receipt authority.
Custom transports use the existing optional `readDefinitions` hook, whose
historical name now covers all ten explicitly allowlisted read actions.

Health source authority was independently read from Coven
[`b3b2d043a4ee586ccbf25ef6aad21db8a1171a54`](https://github.com/OpenCoven/coven/tree/b3b2d043a4ee586ccbf25ef6aad21db8a1171a54):
[`api_routes.rs`](https://github.com/OpenCoven/coven/blob/b3b2d043a4ee586ccbf25ef6aad21db8a1171a54/crates/coven-cli/src/api_routes.rs)
normalizes `/api/v1/actions`;
[`control_plane.rs`](https://github.com/OpenCoven/coven/blob/b3b2d043a4ee586ccbf25ef6aad21db8a1171a54/crates/coven-cli/src/control_plane.rs)
advertises and dispatches the health action, and `automation_health_payload`
explicitly serializes its camelCase keys beneath `event.payload.health`;
[`automations/health.rs`](https://github.com/OpenCoven/coven/blob/b3b2d043a4ee586ccbf25ef6aad21db8a1171a54/crates/coven-cli/src/automations/health.rs)
owns the store-derived `RoutineHealth` values. No new route or mutation is enabled.

### Run history

```ts
const { runs } = await automations.runs('morning', { limit: 10 }, { timeoutMs: 5_000 });
for (const run of runs) {
  console.log(run.id, run.status, run.attempts, run.cancellation);
}
```

`runs(id, query?, operationOptions?)` posts the exact `coven.automations.runs`
action (no `.v1` suffix) and returns `{ runs }` from the completed event payload.
`limit` defaults to 20; the SDK accepts only safe integers from 1 through 100
rather than relying on the producer's fallback/clamping behavior. Runs are
newest-first (`started_at DESC`); tied timestamps have no promised order.
Unknown automation IDs return an empty history. There is no cursor, total,
truncation indicator, individual-run lookup, or all-history guarantee.

The compatibility projection includes nullable runtime/session/output/receipt
references, opaque `logJson` text, nested attempts ordered by attempt number,
and an optional cancellation projection (with absent, not null, optional fields).
The SDK checks requested automation IDs, distinct run/attempt/adoption IDs,
run/occurrence correlations, safe integer bounds and producer attempt/retry
enums and predecessor metadata. Legacy runs can have no occurrence or attempts.
Run status and stored timestamp strings are retained without inventing enums or
timestamp normalization. **This action does not serialize automation revision,
definition digest, timeout or authority profile**, even though some are stored
internally; the SDK neither synthesizes nor certifies them.

The existing authenticated connection, fresh exact-action capability check,
shared deadline/abort scope, strict JSON parsing, and 16 KiB response cap apply.
Large logs/history may exceed that cap even for `limit: 1`; they fail closed
without partial results. Use a smaller limit where possible. The producer reads
runs, attempts and cancellations separately, so this API does not promise an
atomic snapshot. Neither receipt references, cancellation records nor capability
policy labels authenticate receipts or authorize execution.

Run-history source authority was independently read at Coven
[`4e35dd4c99013159fcee4c1ab2f183accdf7a5f8`](https://github.com/OpenCoven/coven/tree/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8):
[`control_plane.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/control_plane.rs)
advertises/dispatches `coven.automations.runs` and `automation_runs_payload`
serializes the exact compatibility shape;
[`automations/runs.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/automations/runs.rs)
defines the bounded run/attempt queries and attempt constraints;
[`automations/cancellation.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/automations/cancellation.rs)
defines `cancellation_for_run` and requester/status fields;
[`api.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/api.rs)
dispatches actions and separately gates receipt access to owner-local IPC.
Receipt reads use the separate producer contract described below.
No unrelated conformance artifact pins change.

### Receipt retrieval

Read a receipt through the same explicitly configured owner-local transport:

```ts
const { receipt, verification } = await automations.getReceipt(
  'receipt-1',
  { timeoutMs: 5_000 },
);
console.log(receipt.receiptId, verification.status); // receipt-1 unverifiable
```

`getReceipt(id, operationOptions?)` requires the exact advertised
`coven.automations.receipt.get.v1` action. Unlike the diagnostic event projections,
this action returns `{ receipt, verification }` from the completed response's
`result`, with no `event`. The producer permits only owner-local IPC and
`public` or `operational` receipts. TCP access and `sensitive`/`restricted`
receipts are refused because a principal-aware read policy is unavailable.
The SDK doesn't fall back to another route or read the store itself.

The returned `verification` is **producer-reported diagnostic data**, not an
SDK verification result. Its only supported status is `unverifiable`.
The producer reports `integrity: "valid"` and `correlation: "valid"` after
checking stored receipt, event, and durable run correlations. Both
`receiptAuthentication` and `runtimeAuthority` remain
`{ status: "unverified", evidence: "unavailable" }`, with the explicit reasons
`PRODUCER_AUTHENTICATION_UNVERIFIED` and `RUNTIME_AUTHORITY_UNVERIFIED`.
`getReceipt()` validates this shape and the requested receipt ID. It does **not**
recompute the receipt digest, authenticate signatures, verify external bindings,
or authorize execution. Use the separate local `verifyReceipt()` function below
for integrity and explicit caller-binding checks. An `integrity.authentication` label such as
`producer-hmac` or `cosign` is metadata, not proof. Even a `succeeded` outcome
does not establish authenticated success or certification.

Receipt IDs are trimmed, then must match the producer's ASCII identifier grammar:
1-160 characters, starting with an alphanumeric character and continuing with
alphanumerics, `.`, `_`, or `-`. The receipt has string
`schemaVersion: "coven.automations.v1"`, not numeric version `1`.
The SDK checks nested fields, enums, string/count bounds, positive safe integers,
digest syntax, unique capability lists, and the producer's lexical UTC timestamp
grammar without normalizing dates. Optional fields are absent, never `null`.
Unknown receipt/nested fields and unsupported versions or variants fail closed.
Returned data may contain private operational details; don't log whole receipts.
Errors never include producer messages, reasons, receipt content, or paths.

The producer's typed rejections become `CovenClientError` with their exact
`code` and `statusCode`: `VALIDATION_FAILED` (400), `NOT_FOUND` (404),
`AUTHORITY_REQUIRED` (403), or `INTERNAL` (500), all non-retryable.
Missing receipts are errors, not invented `null` results. Malformed or crossed
envelopes, unsupported privacy classes, and upgraded verification labels produce
`invalid_response`. The existing 16 KiB / 16-level response bound, fresh
capability check, connected-peer authentication, and shared deadline/abort
scope apply. Large receipts fail closed without partial results.

This hand-authored read projection is pinned to Coven v0.4.4 source
[`4e35dd4c99013159fcee4c1ab2f183accdf7a5f8`](https://github.com/OpenCoven/coven/tree/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8).
[`control_plane.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/control_plane.rs)
advertises/dispatches the action and defines `automation_receipt_result` and
`typed_rejection`;
[`api.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/api.rs)
applies the receipt transport gate, and
[`request_authority.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/request_authority.rs)
allows only `OwnerLocalIpc`;
[`automations/receipts.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/automations/receipts.rs)
defines `read_receipt`, not the separate `read_authorized_receipt`;
[`automations/contract/types.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/automations/contract/types.rs)
and
[`automations/contract/error.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/automations/contract/error.rs)
define the serialized receipt and error constraints. The hand-authored read
projection is also checked against the pinned schemas described below. This
slice does not change artifact canary pins or complete #80 verification,
global feed subscriptions, or authority-bearing commands.

### Local definition digests and event projection

Use the standalone helpers to check supplied Automations objects without making
transport requests:

```ts
import {
  computeDefinitionDigest,
  verifyEventIntegrity,
  reduceAutomationEvents,
} from '@opencoven/coven-client';

export function inspectAutomation(definition: unknown, event: unknown, events: unknown) {
  return {
    definitionDigest: computeDefinitionDigest(definition),
    eventIntegrity: verifyEventIntegrity(event),
    projection: reduceAutomationEvents(events),
  };
}
```

`computeDefinitionDigest()` accepts a complete `CovenAutomationDefinitionDocument`,
including its existing well-formed `integrity` field. It hashes every supplied
normative field and extension using SHA-256 over RFC 8785 JSON, excluding only the
top-level `integrity`. The result is `computed` with a digest, or `invalid` with
`INVALID_DEFINITION`. A computed digest does not compare the supplied integrity;
you can compare it with an independent expected reference. `get()` still returns
the legacy routine projection, which lacks the fields needed to construct a full
definition. The helper never fills defaults or normalizes prompts, schedules,
paths, capabilities, or extension values.

Definition checks cover the pinned structural fields, variants, bounds,
uniqueness, and conditional requirements. They do not validate schedules against
the scheduler or IANA identifiers against Coven's pinned timezone database.
Hashing a reserved delivery shape does not advertise delivery capability.
Bindings and runtime requirements remain unverified authority claims.

`verifyEventIntegrity()` reports `schema` and `integrity` separately. A valid
event without an optional digest returns `integrity: 'unavailable'` with
`INTEGRITY_ABSENT`; a present digest either matches or returns
`INTEGRITY_MISMATCH`. `producerAuthentication` always remains `unverified`.
Nested `integrity` members inside snapshot state are covered by the event digest.

`reduceAutomationEvents()` projects a bounded array from sequence zero or from
an actual canonical `feed.snapshot` followed by its tail. It returns an immutable
`state`, `cursor`, `stream`, and `stateDigest`, or a fixed invalid reason without
partial state. Identical event IDs and bodies deduplicate; changed bodies under
one ID, mixed streams, gaps, stale snapshots, sequence regressions, and invalid
present event digests fail. Each ordinary event replaces the prior payload
projection and carries its canonical `eventWindow`. A snapshot replaces state
exactly. The state digest covers the complete state, including any `integrity`
member, and uses the producer's `sha256:<hex>` format.

For occurrence streams, the reducer checks `payload.from` against a known prior
occurrence state and refuses departure from a known terminal state.
`occurrenceContinuity: 'checked'` means at least one occurrence transition was
checked and all occurrence transitions in this batch had known prior state.
An occurrence transition at the start of a batch has no known prior state,
even at sequence zero. The reducer does not infer one from its `from` field or
assume `none`; that batch therefore reports continuity as unavailable.
An actual preceding occurrence event or a snapshot containing occurrence state
can supply the prior state for later checks. Opaque snapshots or intervening
projections without occurrence state make that check unavailable. The helper
does not enforce every state-machine adjacency, actor, or guard, and does not
claim full all-stream transition validation.
Its `authority` remains `unverified`; local projection is not evidence of execution
or success. There is no persistent replay cache, automatic reset, polling,
prefetch, or implicit invocation by `events()` or `subscribe()`.

All three helpers take an owned snapshot before validation. Limits apply to the
whole input, including a whole reducer batch: depth 16, 4,096 object/array nodes,
8,192 own properties, 262,144 UTF-16 code units across keys and string values, and
4,096 elements per array. Inputs exceeding any limit fail without truncation.
The helpers support finite fractional JSON values in extensions and snapshot
state; schema integer fields still require safe integers. They reject nonfinite
numbers, unsafe integers, lone surrogates, cycles, accessors, sparse arrays, and
unsupported host objects. Receipt verification retains its existing integer-only
JSON domain. Outputs contain fixed reasons without copying prompts or paths into
error messages; projection state itself retains supplied event data.

These helpers pin Coven `aa28d994965a83c0dfba8eaca071e182d605fed1`.
The [fixture provenance](fixtures/automations-pure-v1/manifest.provenance.json)
records executable-source differences: top-level-only integrity exclusion takes
precedence over vector prose saying every integrity member. The pinned
`common.schema.json` description also says extensions never influence digests,
but `types.rs:993–1004` serializes them into the definition body, and
`canonical_json.rs` excludes only top-level `integrity`. The SDK follows that
executable recipe: extension values, including nested `integrity`, affect the
digest. Named vectors in `tests/coven-automations-definition-digest.spec.ts` check
this with independently computed literal digests. They are SDK-authored
executable-recipe checks, not upstream certification. The published golden
includes `extensions: {}` and has digest
`8921b840a98f0b700d0144e70b9418af2431f9863bc4e4d8529b2d9848fa4ce9`;
omitting that field independently yields
`444628a422ccc48f322243fb9c57e6f9f23441a53db7deed5c74bd72c1b86091`.
This directly contradicts the schema prose while preserving the upstream golden.

Rust/schema allow optional draft/invalid `binding.familiarId` and optional
delivery members subject to `outputTarget` requiring `mode`, while the pinned
TypeScript artifact narrows those fields. The wire timezone string carries no
local IANA-validation brand.
The older artifact canary remains independently pinned and is not the runtime
implementation of these helpers.

### Local receipt integrity and binding checks

`verifyReceipt(receipt, trustContext)` checks a receipt's SHA-256 integrity and
the exact identity bindings you supply, without transport or credential access.

```ts
import { verifyReceipt } from '@opencoven/coven-client';

export function checkReceipt(receipt: unknown) {
  return verifyReceipt(receipt, {
    receiptId: 'receipt-daily-notes-0001',
    automationId: 'daily-notes',
    automationRevision: 1,
    occurrenceId: 'daily-notes-1756544400000',
    runId: 'run-daily-notes-0001',
    attemptId: 'att-daily-notes-0001-1',
    familiarId: 'charm',
  });
}
```

Use identities from your independently held expectations. Copying them from
the receipt would only compare its claims to themselves. The configured
`client.automations.verifyReceipt()` convenience performs the same synchronous
local checks and does not invoke capability discovery, observers, or retries.
`getReceipt()` keeps its existing producer-reported verification result.

The local result contains `schema`, `integrity`, individual `bindings`, and fixed
`reasons`. A malformed receipt or context, an integrity mismatch, or a binding
mismatch makes `status` `invalid`. Otherwise `status` is `unverifiable`.
`receiptAuthentication` and `runtimeAuthority` always remain
`{ status: "unverified", evidence: "unavailable" }`. An unkeyed digest can be
recomputed by anyone; `producer-hmac`, `cosign`, and `succeeded` labels do not
establish authenticated provenance, delivery success, or verified execution.

You can also supply `occurrenceFenceGeneration`, `attemptNumber`, `runtimeId`,
`definitionDigest`, `deliveryDigest`, and `resultDigest` expectations. An omitted
expectation produces `unavailable` for that binding, even when the receipt has a
value. A supplied expectation whose receipt field is missing or different is
`invalid`. Digest expectations use the exact `{ algorithm: "sha256",
canonicalization: "jcs-rfc8785", value }` shape. They compare references only;
the verifier does not read or verify definition, delivery, or result artifact
bytes. It does not derive a full-definition digest from `get()`'s legacy
projection or invent a digest over the runtime descriptor.

Input must fit the supported public/operational receipt projection. Unknown
fields and variants, accessors, `toJSON`, cycles, undefined values, lone
surrogates, and nonintegral or unsafe numbers are rejected. Owned snapshots are
bounded to depth 16, 4,096 object/array nodes, 8,192 properties, and 262,144 total
string code units per input, with at most 4,096 elements per array. Results are deeply
immutable and contain no receipt content, IDs, prompts, paths, or producer errors.

The hash follows Coven's
[`canonicalize_without_integrity`](https://github.com/OpenCoven/coven/blob/aa28d994965a83c0dfba8eaca071e182d605fed1/crates/coven-cli/src/automations/contract/canonical_json.rs)
and
[`AutomationReceipt::verify_integrity`](https://github.com/OpenCoven/coven/blob/aa28d994965a83c0dfba8eaca071e182d605fed1/crates/coven-cli/src/automations/contract/types.rs):
RFC 8785 canonical JSON with only the top-level `integrity` member removed,
UTF16 key ordering, and ECMAScript primitive encoding. The pinned
[schema and vector manifest](fixtures/automations-receipt-v1/manifest.provenance.json)
records exact source paths, commit, and SHA-256 hashes. Tests mechanically cover
the schema's fields, required properties, closed objects, and supported enum
variants, and execute the producer's valid and tampered receipt vectors.
This increment leaves authentication, authority verification, and the remaining
[SDK #80 phases](https://github.com/OpenCoven/sdk/issues/80) open.

### Occurrence and run inspection

```ts
const { occurrences } = await automations.occurrences(
  { view: 'eligible', limit: 10 },
  { timeoutMs: 5_000 },
);
for (const occurrence of occurrences) {
  const detail = await automations.getOccurrence(occurrence.id);
  console.log(detail.occurrence?.runsTruncated);
}
```

`occurrences({ view, limit?, automationId? }, operationOptions?)` calls the
exact advertised `coven.automations.occurrence.list.v1` action. Without
`automationId` it is **global scheduler inspection**. With `automationId`, the
producer restricts the view to that automation inside its query, so `limit`
bounds that automation's rows; the SDK refuses a filtered page that names any
other automation. An empty or non-string `automationId` is rejected before any
transport I/O. This action has no cursor; page one automation's full history
with `occurrenceHistory()` below.
The required view is `due`, `eligible`, `claimed`, `running`, or
`recovery_required`; limits are integers 1–100 (default 20). Unsupported query
fields are rejected rather than silently suggesting filtering or pagination.
Due means planned and scheduled by the producer's current time; eligible is
the producer's scheduling decision, not a client authorization decision.
The producer returns bounded oldest-scheduled-first records (ID tie-breaker).

`getRun(runId, operationOptions?)` calls `coven.automations.run.get.v1` and
returns `{ run: null }` for absence, or one run with its attempts, read from one
producer snapshot. The run has the same projection and validation as an
occurrence detail's nested runs (below): exact run ID, occurrence, revision,
nullable digest, authority profile and timeout, at most ten attempts, and no
cancellation projection. Both reads need a Coven producer that advertises them
([coven#1155](https://github.com/OpenCoven/coven/issues/1155)); an older producer
yields `capability_unsupported`, never a fallback.

### Lifecycle commands

```ts
const outcome = await automations.pause('morning', 4, {
  adoptionKey: 'adopt:pause:morning:2026-09-28',
  intent: 'Pause the morning routine for the holiday.',
  principalId: 'principal:owner',
}, { reason: 'Holiday freeze.', timeoutMs: 5_000 });

if (outcome.outcome === 'rejected' && outcome.error.code === 'REVISION_CONFLICT') {
  console.log('stored revision is', outcome.error.currentRevision);
}
```

`activate`, `pause`, `disable` and `tombstone` take `(automationId, expectedRevision, context, options?)`. Each sends one spec command envelope as `coven.automations.command.v1` through the transport's optional `sendCommand` hook.

**The context.** It carries:

- `adoptionKey`: the idempotency key, 8 to 200 characters of `[A-Za-z0-9._:-]`;
- `intent`: 1 to 1000 characters;
- `principalId`;
- an optional `correlationId`.

`options` may carry a `reason` of up to 500 characters (not for `tombstone`) and the usual `signal`, `timeoutMs` and `observer`. Every field is validated before any I/O, and a bad value fails with `invalid_options`.

**The send gate.** A command is sent only when the producer advertises both `coven.automations.command.v1` and the command's own action, such as `coven.automations.definition.pause.v1`. Otherwise it fails with `capability_unsupported`, and nothing is sent. The built-in Unix and Windows transports serialize a freshly rebuilt, exactly keyed envelope for these commands and refuse anything else. For `createDraft` and `revise` they also recompute the definition's digest and refuse a body that does not match its `integrity`, a create that is not `revision: 1` in `draft`, or a revise that is not `expectedRevision + 1`. A transport without `sendCommand` cannot mutate: the call fails with `unsupported_operation`.

**The outcome.** The result is a typed discriminated union:

- `committed`, with `revision`, `result` and `eventRef`;
- `replayed`, where the same key was already applied; it carries the first commit's `replay.firstCommittedAt`;
- `rejected`, with a typed `error.code` such as `REVISION_CONFLICT` (with `currentRevision`), `ILLEGAL_TRANSITION`, `GONE_TOMBSTONED`, `ADOPTION_REPLAY_MISMATCH` or `AUTHORITY_REQUIRED`, and nothing committed. Producer messages are not copied.

**An unknown outcome.** If anything fails after the request is handed to the transport, the call throws `outcome_unknown` (`retryable: true`). That covers a dropped connection, the deadline passing mid-flight, and a response that does not prove what happened. **Resend with the same `adoptionKey`** to learn the outcome: the producer replays a committed command instead of applying it twice. A fresh key could apply it again. Cancellation or refusal before the send never reports `outcome_unknown`.

**Authority.** `principalId` is recorded with the command; it is not an authority grant. The producer accepts automation mutations only over owner-local IPC, which is the only place the built-in transports connect.

**Definitions.** `createDraft(definition, context, options?)` and `revise(automationId, expectedRevision, definition, context, options?)` send a rich `coven.automations.v1` definition:

```ts
const created = await automations.createDraft({
  schemaVersion: 'coven.automations.v1',
  automationId: 'daily-notes',
  display: { name: 'Daily notes' },
  trigger: { variant: 'schedule', version: 1, schedule: { rrule: 'FREQ=DAILY;BYHOUR=9', timezone: 'utc' } },
  action: { variant: 'familiarInvocation', version: 1, prompt: 'Write the daily reflection.' },
  binding: { familiarBindingPolicy: 'exact', familiarId: 'charm', authority: { approvalPolicyRef: 'policy://authority/familiars/charm' } },
  runtimeRequirements: { runtimeId: 'coven-code', capabilities: ['sessions.launch'] },
  policies: {
    timeout: { perRunMinutes: 30 },
    retry: { maxAttempts: 1, backoffPolicy: 'none' },
    concurrency: { overlap: 'forbid' },
    misfire: { disposition: 'latest' },
    retention: { occurrenceHistory: { classification: 'standard' } },
  },
}, { adoptionKey: 'adopt:create:daily-notes', intent: 'Add the daily notes routine.', principalId: 'principal:owner' });
```

- **The SDK sets the bookkeeping fields.** For `createDraft` it sets `revision: 1`, `lifecycleState: "draft"` and the JCS `integrity`; for `revise` it sets `revision: expectedRevision + 1` and `integrity`. Passing any of these yourself is `invalid_options`, as is a body that fails the structural `coven.automations.v1` check, including a missing or unknown `schemaVersion`. Accessor-backed properties are refused without being invoked.
- **Lifecycle on revise.** You choose `lifecycleState`, and it must be one a revise can write: `paused` for a draft, invalid or paused definition, `active` for an active one. The producer refuses anything else with `ILLEGAL_TRANSITION`. A new definition runs nothing until `activate`.
- **Producer limits.** The producer refuses variants it cannot execute with `CAPABILITY_UNSUPPORTED`, rather than dropping them: delivery policies, activation windows, and retention classes other than `standard`.
- **Size and depth bounds.** A committed answer carries the definition up to four times, so the SDK refuses, before sending, a definition over 192 KiB of serialized JSON or nested deeper than 10 levels, and accepts answers up to 1 MiB. Any definition the SDK sends therefore has a committed answer it can decode, so a commit is never reported as `outcome_unknown` for size. The longest schema-valid ASCII prompt (100,000 characters) fits.

**Not available.** Run, cancel, retry and approval wait on OpenCoven/coven#857.

These commands need a producer with the command envelope ([coven#1176](https://github.com/OpenCoven/coven/pull/1176)); `createDraft` and `revise` also need rich-definition support ([coven#1185](https://github.com/OpenCoven/coven/pull/1185)).

### Missions

A mission is one owner-submitted, one-shot run of an exact familiar revision on
one project ([OpenCoven/coven#1313](https://github.com/OpenCoven/coven/issues/1313)).
`CovenMissionsClient` submits, reads, watches and cancels one. It keeps no state
and stores nothing: every state it reports is the daemon's `MissionView`.

```ts
import {
  CovenMissionUncertain, createCovenAutomationsUnixTransport, createCovenMissionsClient,
} from '@opencoven/coven-client';

const missions = createCovenMissionsClient({
  transport: createCovenAutomationsUnixTransport(endpoint, { security }),
  principalId: 'principal:chat',
});

const adoptionKey = crypto.randomUUID(); // store it before you send
try {
  const { missionId } = await missions.submit({
    familiar: { rootId, revisionId },
    envelope: { id: 'r0-read.1', descriptorDigest },
    project: { cwd: '/Users/me/project' },
    task: { statement: 'Diagnose the failing build', prompt: 'Read the last CI log and report the cause.' },
    limits: { timeoutMinutes: 10 },
    validUntil: new Date(Date.now() + 10 * 60_000).toISOString(),
  }, { adoptionKey });
  for await (const view of missions.watch(missionId)) render(view);
} catch (error) {
  if (error instanceof CovenMissionUncertain) showChecking(error.missionId);
  else throw error;
}
```

**Ids.** The daemon derives a mission's id from the submit's adoption key, so a
caller that stored only the key can re-attach:
`CovenMissionsClient.missionIdFor(adoptionKey)` is `mission-` followed by the
first 32 hex digits of SHA-256 over the key. It is pure.

**Submit.** `submit(input, options?)` binds the familiar revision, the runtime
envelope, the project directory, the task, the timeout and `validUntil`.
Everything is validated before any I/O: the statement is 1 to 200 characters,
the prompt is at most 32 KiB of UTF-8, the timeout is 1 to 60 minutes, and the
directory is absolute. A bad value fails with `invalid_options`. The adoption key
is generated with `crypto.randomUUID()` when you don't pass one, and is returned
on the result. The result is `committed`, or `replayed` when the key had already
committed; a replay never launches again. The answer must carry the id derived
from the key and bind the familiar revision, envelope, statement and expiry that
were sent. Anything else is treated as an unknown outcome.

**A lost answer.** Once a submit is handed to the transport, no failure proves
it was not applied. The client resends the same bytes under the same key, up to
three times within the deadline. If the outcome is still unknown, `submit`
throws `CovenMissionUncertain` (`code: 'outcome_unknown'`), carrying
`adoptionKey` and `missionId`. Show "checking", call `get(missionId)`, and
resubmit with the same key and input only if it answers `NOT_FOUND`. Never show
"nothing happened".

**Refusals.** A daemon refusal throws `CovenMissionError` with the typed `code`
and `statusCode`, and nothing was committed by the request. `CONCURRENCY_LIMIT`
means another mission for this familiar is active in this project.
`ADOPTION_REPLAY_MISMATCH` carries `conflictOutcome`, saying what the key
actually committed. A familiar revision that is no longer current is
`REVISION_CONFLICT`, with the current one in `currentRevisionId`. An envelope
the daemon does not enforce is `CAPABILITY_UNSUPPORTED`. A cancel of a mission
that has already settled is `ILLEGAL_TRANSITION`, with its terminal view in
`mission`. Daemon messages are not copied.

**Get.** `get(missionId)` returns the current view. A mission that does not
exist, or that belongs to another principal, is `CovenMissionError` with
`NOT_FOUND`, never an empty view. The view is checked for internal consistency:
a terminal view carries its result, a refused or failed one carries its reason,
and the prompt is never echoed.

**Watch.** `watch(missionId, options?)` yields a view each time its `revision`
increases, and ends after the first terminal view. The view is the daemon's
authority, so `watch` reads it every `pollIntervalMs` (100 to 60 000 ms,
default 1 000) rather than inferring change from events. A client that
restarts resumes by passing the last `revision` it showed as `afterRevision`.
`timeoutMs` bounds each read, not the watch; end it with `signal` or `return()`.
With `expect: { principalId, familiar }`, a view for another principal or
familiar is not yielded and the iterator throws `CovenMissionContextMismatch`.

**Cancel.** `cancel(missionId, { reason? }, options?)` carries its own adoption
key; replaying it returns the same cancellation. The receipt's `outcome` is
`cancelled`, `pending`, `lost_to_completion` or `recovery_required`. The client
never infers it: `lost_to_completion` means the mission completed.

**Authority.** `principalId` is recorded with each command; it is not an
authority grant. The daemon takes the mission's principal from the owner-only
socket or pipe, which is the only place the built-in transports connect, and
refuses mission commands over TCP. Commands are sent only when the daemon
advertises `coven.automations.command.v1` and the command's own
`coven.automations.mission.*.v1` action; otherwise they fail with
`capability_unsupported` and nothing is sent.

Missions need a Coven daemon that implements the mission commands. Until
Runtime Authority exists (OpenCoven/coven#857), a submitted mission settles
`unavailable` with reason `authority_unavailable` and launches nothing.

### Occurrence history

```ts
const page = await automations.occurrenceHistory('morning', { limit: 50 });
for await (const occurrence of automations.iterateOccurrenceHistory('morning', {
  limit: 50,
  maxPages: 10,
})) {
  console.log(occurrence.scheduledFor, occurrence.state);
}
```

`occurrenceHistory(automationId, { limit?, cursor? }, operationOptions?)` calls
`coven.automations.occurrence.history.v1` and returns one sdk-core `Page`:
`{ automationId, data, cursor: { hasMore, current?, next? } }`. It covers every
state, terminal ones included, newest first by `scheduledFor` then `id`, and
reflects whatever the producer's history retention has kept. `limit` is 1–100
(default 20). `cursor` is the opaque `next` of an earlier page for the same
automation; the SDK accepts only canonical unpadded base64url of at most 512
characters and rejects anything else, and any other query field, before
transport I/O. The producer pages by keyset, so occurrences planned while a
caller pages never shift a later page.

The SDK refuses a page that names another automation, holds more than `limit`
rows, is not strictly newest first by instant (a millisecond `.123Z` and a
nanosecond `.123000000Z` are the same instant, ordered by `id`), repeats a row, claims `hasMore` without a
fresh `next` or on a short page, carries `next` without `hasMore`, or does not
echo the requested cursor as `current`. History responses are capped at
**256 KiB**, enough for 100 records; a larger page fails closed, and a smaller
`limit` reads it.

`iterateOccurrenceHistory(automationId, { limit?, cursor?, maxPages?, signal?,
timeoutMs?, observer? })` walks pages with sdk-core `iteratePages`: it needs
`maxPages` or a caller-owned `signal`, stops at `hasMore: false`, and refuses a
cursor that does not advance. Its `limit` defaults to sdk-core's 50, and
`timeoutMs` bounds the whole walk, while each page read keeps the client's
per-call timeout. Both need a Coven producer that advertises the action
([coven#1157](https://github.com/OpenCoven/coven/issues/1157)); an older
producer yields `capability_unsupported`.

### Run history

```ts
const page = await automations.runHistory('morning', { limit: 20, occurrenceId: 'occurrence-1' });
for await (const run of automations.iterateRunHistory('morning', { limit: 50, maxPages: 10 })) {
  console.log(run.startedAt, run.status, run.attempts.length);
}
```

`runHistory(automationId, { limit?, cursor?, occurrenceId? }, operationOptions?)`
calls `coven.automations.run.history.v1`. It returns an sdk-core `Page` of
`{ automationId, occurrenceId?, data, cursor }`: one automation's runs, newest
first by start instant then `id`, each with its attempts and any cancellation,
read in one producer snapshot. Each run has the same projection and validation
as `runs()`. `occurrenceId` restricts the page to one occurrence's runs. Its
cursors are bounded at **256 characters**, tighter than occurrence history's 512.

The SDK refuses a page that:

- names another automation;
- echoes an `occurrenceId` that was not requested, or omits one that was;
- holds a run of another occurrence;
- breaks newest-first order by instant;
- misreports `hasMore` or `next`;
- does not echo the requested cursor.

Responses share the 256 KiB history cap, so a page of large `logJson` values
fails closed and a smaller `limit` reads it.

`iterateRunHistory(automationId, boundedPageOptions, { occurrenceId? })` walks
pages with sdk-core `iteratePages`. Both need a Coven producer that advertises
the action ([coven#1160](https://github.com/OpenCoven/coven/pull/1160)).

`getOccurrence(id, operationOptions?)` calls
`coven.automations.occurrence.get.v1` and returns `{ occurrence: null } for
absence, or a diagnostic detail record. The detail contains up to **20 oldest
runs** (started-at/ID order), ascending-number attempts and `runsTruncated`.
Truncation does not supply a continuation cursor. Unlike the standalone
compatibility `runs()` projection, these nested runs include
`automationRevision`, nullable `definitionDigest`, `authorityProfile` and
`timeoutAt`, and no cancellation projection. The SDK validates required field
types, safe integers, bounds, unique IDs, attempt metadata, and
occurrence/run/automation/revision/digest correlation. Nullable stored values
are preserved; opaque occurrence kind/state and run status strings are not
coerced into normative contract enums.

Both operations recheck exact capability support and share one deadline/abort
scope across capability and action reads, with independently authenticated Unix
connections. Missing capabilities never fall back to another action. The
existing **16 KiB response cap fails closed**, including when nested logs
exceed it. The producer reads each occurrence list/detail in a database
transaction, but no snapshot continuity is promised between SDK calls.
Leases, fences, states, authority-profile labels and digest strings remain
diagnostics. Receipt IDs are references only: this is not authenticated receipt
evidence, execution authorization, positive authority acceptance or certification.

**Occurrence source provenance:** freshly inspected Coven main at
[`4e35dd4c99013159fcee4c1ab2f183accdf7a5f8`](https://github.com/OpenCoven/coven/tree/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8).
[`control_plane.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/control_plane.rs)
advertises and dispatches both exact actions, validates view/limit, and defines
`automation_occurrence_value` and the list/detail event payloads;
[`automations/inspection.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/automations/inspection.rs)
defines nullability, ordering, snapshot transactions and the 20-run truncation;
[`api.rs`](https://github.com/OpenCoven/coven/blob/4e35dd4c99013159fcee4c1ab2f183accdf7a5f8/crates/coven-cli/src/api.rs)
routes authenticated `POST /api/v1/actions`. There is no advertised individual
run-read action at this pin; `coven.automations.run` is a mutation and is never
used as a read fallback. Independent receipt authentication, global feed subscriptions,
per-automation occurrence history and individual-run lookup remain unimplemented.

### Bounded event subscriptions

Use `events()` to read one page or `subscribe()` to iterate pages from a domain
stream. Both require the exact advertised
`coven.automations.events.subscribe.v1` action and the existing opt-in
Automations transport.

```ts
const stream = { kind: 'automation', id: 'morning' } as const;
const page = await automations.events({ stream }, { timeoutMs: 5_000 });
for (const event of page.events) console.log(event.kind, event.sequence);

// Resume only after you have processed every event in the saved page.
const controller = new AbortController();
for await (const next of automations.subscribe(
  { stream, checkpoint: page.checkpoint },
  { signal: controller.signal, timeoutMs: 5_000 },
)) {
  for (const event of next.events) console.log(event.kind, event.sequence);
  // Persist next.checkpoint together with your successfully updated read model.
}
```

The producer returns at most 100 events per request. Each iterator `next()`
performs one capability check and one action request, with a shared per-page
deadline. There is no prefetch, polling, automatic retry, or persistent socket.
An empty page is yielded once so you can save its checkpoint, then iteration
ends. Call `subscribe()` again with that checkpoint when you choose to check
for new events. Concurrent `next()` calls fail with `invalid_options` instead
of queuing more pages. Breaking the loop or calling `return()` or `throw()` aborts that
iterator's pending request. Other iterators keep their own cancellation scope.

Supply either an exclusive numeric `after` cursor or an opaque `checkpoint`.
Omit both to start at the beginning. Explicit `limit` and `from` fields are
rejected. Supported stream kinds are `automation`, `occurrence`, and `run`.
The global `feed/all` mode is unsupported: the producer returns domain events
with a separate feed cursor, so an event's `sequence` cannot establish global
ordering. The SDK does not substitute domain sequences for feed positions.

Every page is validated and deeply frozen before it is returned or yielded. The SDK binds the
page and its events to the requested stream, requires gapless sequence order,
ignores identical duplicate event IDs within a page, and refuses conflicting
duplicates. It checks that a resumed iterator page starts after the previous
page's `nextAfter`. Earlier deliveries outside the current page are refused
as cursor regressions; the SDK retains no unbounded event-ID history. Explicit
`feed.snapshot` events may advance a domain cursor to `throughSequence`.
Their `state` remains opaque data for your application to validate and apply.
Event producer and integrity fields are diagnostic data; reading them does
not authenticate a receipt or authorize execution.

An expired checkpoint surfaces `CovenClientError.code === 'CURSOR_EXPIRED'`
with HTTP status `410`. Unknown checkpoints surface `NOT_FOUND`; invalid
checkpoint bindings surface `VALIDATION_FAILED`. Errors close the iterator.
The SDK never resets a cursor or fetches an earlier page automatically.
Choose and validate your recovery source explicitly before opening a new
subscription. Persist a checkpoint only after committing the whole page;
stopping midway and saving that page's checkpoint would skip its remaining
events on reconnect.

Event responses are capped at 1 MiB and 100 wire events, with the existing
16-level JSON depth limit. Oversized or malformed pages fail closed without
yielding partial events. All other Automations and policy response limits
remain 16 KiB, except occurrence and run history (256 KiB). A producer page larger than the event byte cap cannot be
retried with a smaller subscription limit because the producer forbids that
field. The SDK does not silently truncate it.

This additive surface follows Coven commit
[`aa28d994965a83c0dfba8eaca071e182d605fed1`](https://github.com/OpenCoven/coven/tree/aa28d994965a83c0dfba8eaca071e182d605fed1):
[`control_plane.rs`](https://github.com/OpenCoven/coven/blob/aa28d994965a83c0dfba8eaca071e182d605fed1/crates/coven-cli/src/control_plane.rs)
owns the advertised action, fixed page size, mutually exclusive cursors, and
completed `result` envelope;
[`events.rs`](https://github.com/OpenCoven/coven/blob/aa28d994965a83c0dfba8eaca071e182d605fed1/crates/coven-cli/src/automations/contract/events.rs)
owns checkpoint expiry, stream binding, exclusive cursors, and snapshots;
[`types.rs`](https://github.com/OpenCoven/coven/blob/aa28d994965a83c0dfba8eaca071e182d605fed1/crates/coven-cli/src/automations/contract/types.rs)
and the versioned event schema own the validated payload union. Exact schema
and canonical duplicate-delivery fixture bytes and source digests are recorded
in `fixtures/automations-events-v1/provenance.json`. These adapter tests do not
claim live-daemon or artifact conformance and do not complete #80's remaining
global feed, receipt authentication, individual-run lookup, per-automation
history, or command-authority work.

`capabilities()` sends only `GET /api/v1/capabilities`. It reads the uniquely identified
`coven.automations` catalog entry, preserves supported, experimental and refused
variants separately, and accepts only profile version 1,
`coven.automations.v1`. Missing advertisements, planned capabilities, and older
entries without negotiation profiles return explicit `unavailable` reasons.
Malformed/duplicate entries, incompatible profiles, invalid UTF-8/JSON,
oversized bodies and non-200 HTTP responses fail with `CovenClientError`;
an HTTP failure is **not** projected as absence. Errors do not retain response
bodies or provider error causes. Unknown advertised variant strings are data,
not SDK execution support; experimental entries are not implicitly opted into.

The built-in transports enforce platform ownership, permissions, connected-peer
authentication, and post-connect identity checks before writing, with no retries,
TCP fallback, or redirects. They bound headers to 64 KiB and response bodies to 16 KiB,
including error bodies. A five-second default operation deadline covers
endpoint inspection as well as I/O; direct transport calls are capped at five
minutes. Cancellation destroys active sockets. Windows uses its named-pipe
factory and is still rejected by the Unix factory. Injected
`CovenAutomationsTransport` implementations must enforce equivalent trust,
framing and operation limits and return raw response bytes.

**Capability provenance:** this read surface follows Coven commit
[`c56c2e2f10329c05df9273ac48914cf6b7ebb410`](https://github.com/OpenCoven/coven/tree/c56c2e2f10329c05df9273ac48914cf6b7ebb410):
[`control_plane.rs`](https://github.com/OpenCoven/coven/blob/c56c2e2f10329c05df9273ac48914cf6b7ebb410/crates/coven-cli/src/control_plane.rs)
defines `CapabilityCatalog` and the Automations entry;
[`capability_negotiation.rs`](https://github.com/OpenCoven/coven/blob/c56c2e2f10329c05df9273ac48914cf6b7ebb410/crates/coven-cli/src/automations/capability_negotiation.rs)
defines the serialized profile;
[`api.rs`'s `routes_control_capabilities_discovery_to_json` test](https://github.com/OpenCoven/coven/blob/c56c2e2f10329c05df9273ac48914cf6b7ebb410/crates/coven-cli/src/api.rs#L20489)
binds the actual GET response to packaged
[`capabilities.json`](https://github.com/OpenCoven/coven/blob/c56c2e2f10329c05df9273ac48914cf6b7ebb410/spec/coven-automations/v1/capabilities.json).
SDK tests use synthetic contract-shaped responses, not a new certified artifact.
The earlier immutable artifact canary pin remains unchanged.

This is a focused part of [SDK #80](https://github.com/OpenCoven/sdk/issues/80),
not its completion. A local authenticated channel and an advertised capability
are **not receipt authentication, execution authorization, or certification**.
No individual-run retrieval, independent receipt authentication, global feed subscription,
mutation, or positive authority acceptance is implemented here. Producer rich
execution (#1054), trust (#857), and certification (#858) remain separate.
The unified `@opencoven/sdk` coordinates health and exposes the configured
Automations namespace through its existing Coven client.

## Session-policy admission v1 (refusal only)

Depend directly on **`@opencoven/coven-client`** and import these APIs from its
supported package root, not from a workspace source path or the private CLI.
This is one of the SDK's four release-inventory packages. Like the other
release packages, its source manifest remains private behind the repository's
pre-release publishing gates; this does not make it a CLI-only workspace API.
`@opencoven/sdk` remains the optional health coordinator and does not implicitly
create, activate, or re-export the policy client.

The authoritative contract is
[`coven.session-policy.v1`](https://github.com/OpenCoven/coven/blob/8ae022a70ce2506e0e3b4345b8e567fe94380ce5/spec/coven-session-policy/v1/README.md).
Its only restricted-launch outcome is a correlated **HTTP 409** response with
`decision: "rejected"`, `code: "enforcement_unavailable"`, and
`admission: "not_started"`. No production enforced adapter exists. This SDK
reports a schema-validated server refusal, not verified authority, a running
process constraint, a signature, or proof that other processes are stopped.
Fabricated accepted responses, session IDs, receipts, and effective grants
are rejected.

`CovenSessionPolicyClient` accepts an explicit `CovenSessionPolicyTransport`.
Use `createCovenSessionPolicyUnixTransport(endpoint, options)` for real Unix
IPC. It reuses the existing current-UID, non-symlink socket, permission,
connected-peer, and post-connect path-identity validation. It pauses the socket
until validation completes, then sends one fixed request and destroys the
socket on completion, cancellation, or failure. A reviewed native
`security: { platform: 'unix', peerIdentity }` adapter is still mandatory;
the SDK does not invent peer credentials. Windows endpoints fail with
`unsupported_platform`; no Windows policy factory is exposed.

There is no automatic endpoint discovery. Call `discoverCovenEndpoint()`
explicitly if needed, then opt into the policy factory separately. Do not
adapt the health transport, treat health capabilities as approval, or replace
peer authentication with path or discovery metadata. Construction performs no
I/O; client methods and direct transport requests perform I/O only when called.

The transport's discriminated request union contains exactly two routes:
`GET /api/v1/session-policy` and `POST /api/v1/sessions/restricted`. It exposes
no headers, credentials, arbitrary methods, or arbitrary paths. The adapter
must honor `OperationContext.signal` and `deadline`, enforce the supplied
16 KiB response limit while reading (including HTTP error bodies), and return
the **raw JSON `Uint8Array` plus numeric HTTP status**. It must bound connection,
headers and framing, disable redirects and automatic retries, and never fall
back to legacy launch. The consumer independently checks body size and strict
JSON; already-parsed objects are not an acceptable substitute.

The built-in policy transport enforces those constraints independently: 2-second
connect and 5-second request timeouts, 64 KiB headers, 16 KiB response bodies,
and a total frame allocation bound. Its whole-operation deadline also covers
initial path inspection and connected-peer validation, defaults to five seconds
when no context deadline is supplied, and never exceeds five minutes. The
request union and body array must be frozen; mutable octets, unknown methods,
paths, headers, and altered limits are rejected before I/O. No transport option
can raise the fixed policy size limits. Optional `dependencies` expose the same
isolated socket/UID/stat test seams as the health transport.

Protected invocation workflows must stop on unavailable discovery **before any
prompt-bearing POST**. The SDK also exposes an explicit POST for separately
requested refusal correlation; it is not automatic continuation, fallback, or
permission to start a runtime.

```ts
import {
  createCovenSessionPolicyClient,
  createCovenSessionPolicyUnixTransport,
  isCovenSessionPolicyError,
  type CovenDiscoveredEndpoint,
  type CovenRestrictedLaunchRequest,
  type CovenUnixPeerIdentityAdapter,
} from '@opencoven/coven-client';

declare const endpoint: CovenDiscoveredEndpoint;
declare const nativeUnixPeerIdentity: CovenUnixPeerIdentityAdapter;
declare const request: CovenRestrictedLaunchRequest;
const policy = createCovenSessionPolicyClient({
  transport: createCovenSessionPolicyUnixTransport(endpoint, {
    security: { platform: 'unix', peerIdentity: nativeUnixPeerIdentity },
  }),
});

// Explicit availability metadata, never authorization; no supported profiles in v1.
const availability = await policy.discover({ timeoutMs: 5_000 });
console.log(availability.enforcement); // "unavailable": protected invocation stops here.
```

For a separately requested refusal-correlation probe, the low-level POST remains
available using the explicitly constructed client:

```ts
// Caller supplies lowercase canonical request/invocation UUIDs and an admission
// deadline, then serializes once. Do not retry or silently create new identities.
const body = new TextEncoder().encode(JSON.stringify(request));
try {
  const refusal = await policy.launchRestricted(body, { timeoutMs: 5_000 });
  console.log(refusal.decision); // Always "rejected", never a grant.
} catch (error) {
  if (!isCovenSessionPolicyError(error)) throw error;
  console.error(error.code, error.delivery);
}
```

`launchRestricted()` copies the supplied octets before parsing, freezes a
`readonly number[]` snapshot for transport, and binds the response to SHA-256
of that exact snapshot plus both canonical UUIDs. Transport implementations
send `Uint8Array.from(request.body)` once, without JSON reserialization.
Whitespace, escaping and Unicode representation intentionally affect the
digest. The SDK does not perform semantic JSON canonicalization, path
resolution, familiar lookup, credential lookup, or TypeScript authority
decisions. The canonical v1 harness wire IDs are exactly `codex`, `claude`,
`coven-code`, and `copilot`. The typed request and parser reject other IDs;
this mirrors the versioned server schema, not an independent backend/authority
allowlist. Every listed harness still has unavailable enforcement.

Callers such as Wand may use Swift `JSONEncoder.sortedKeys`; pass the resulting
frozen bytes unchanged. Sorted keys do not authorize normalization of slash
escaping, Unicode, whitespace, or trailing newlines before sending or binding.

Requests are bounded to 1 MiB and depth 16, with the contract's closed envelope,
field types and UTF-8 limits. Duplicate keys (including escaped equivalents),
invalid UTF-8, unpaired Unicode surrogates, unknown contract/profile revisions,
and malformed payloads fail closed. Discovery and refusal responses are
closed schemas; supported profiles or positive enforcement metadata do not
become permission. Admission expiry must be a safe integer strictly in the
future and at most five minutes away. It is **not a running-process lease**.
The deadline must use a plain signed integer JSON token; fractional or
exponential encodings are invalid even when their numeric value is integral.
Negative safe integers are structurally integers but already expired, so this
consumer rejects them locally without sending a request.

Both operations accept existing `OperationOptions` and constructor operation
defaults. Unlike legacy `health()`, the opt-in policy consumer defaults to a
five-second timeout, caps operations at five minutes, and further bounds a
launch by its admission deadline. Request preparation consumes the timeout
budget. Cancellation/deadlines are checked before dispatch and after response
handling; non-cooperative transports cannot make the client wait indefinitely
or turn a late reply into a refusal. Stopping underlying I/O still requires a
cooperative adapter.

`CovenSessionPolicyError` exposes allowlisted `normalized` metadata,
`code`, optional HTTP status and validated request correlation fields,
`retryable: false`, and `delivery`:
`not_attempted` means the transport was not called; `unknown` means it was
called but no valid correlated refusal was received. Neither error state
asserts `not_started`. Invalid request/response, unsupported contract/profile,
HTTP errors, transport failure, invalid options, cancellation, and timeout
have explicit codes, as does unsupported platform. HTTP errors do not expose raw server messages or details;
transport errors and cancellation do not retain sensitive causes. Observer
error metadata also declares retries disabled. There is no automatic
discovery, POST retry, redirect, or fallback in this consumer.

Positive runtime enforcement, reviewed backend tuples, grants, leases,
revocation, and lifecycle events require a separate future contract. They
cannot be added to this refusal-only revision as metadata.

### Shared conformance vectors

You can reproduce these vectors from Coven producer commit
`8ae022a70ce2506e0e3b4345b8e567fe94380ce5`.
`fixtures/session-policy-v1/manifest.provenance.json` pins that commit, the source
manifest path, and its SHA-256. This separate SDK provenance file records the
origin of the samples, not runtime enforcement or authority.

The authoritative server vectors are copied byte-for-byte into
`fixtures/session-policy-v1/{request,refusal,discovery,manifest}.json`.
The manifest fixes admission time at `1799999700000`. Its 421-byte request
includes one trailing LF and binds to
`sha256:c61bac56f84d1f3fddd5e70da35a7e8906f9bd4bac769b5d4ad61769dae83fdb`.
These historical fixed-time samples are for conformance, not live launch.
Response fixture files include LF for source hygiene; server HTTP response
bodies do not. Both response whitespace forms are valid, but request bytes must
never be trimmed or reserialized for binding.

## Discover and check health

`createDiscoveredCovenClient(options)` resolves the current daemon, verifies
that the supplied transport-security provider matches that endpoint's
platform, and returns the existing typed `CovenClient`. On Unix, a non-empty
`COVEN_HOME` directly selects `<COVEN_HOME>/coven.sock`. On Windows, including
when `COVEN_HOME` is set, discovery obtains the selected profile's authoritative
`state.daemon_ipc` from exact `coven config paths --json` output; it never
constructs a pipe name from the Unix convention or redirects through
`daemon.json.socket`.

CLI fallback requires an explicit `dependencies.resolveExecutable` provider.
The returned path is canonicalized and must be an absolute regular executable
named `coven` (`coven.exe` on Windows). Unix executables must be owned by the
current UID or root and must not be group/world writable. Windows discovery
also requires an injected `windowsFileTrust.validate()` ownership/trust
provider. The SDK then executes only the fixed `config paths --json` argv with
no shell, a bounded timeout/output buffer, and a small allowlisted environment.
Callers cannot supply an arbitrary command or argv.

```ts
import {
  createDiscoveredCovenClient,
  discoverCovenEndpoint,
  type CovenUnixPeerIdentityAdapter,
} from '@opencoven/coven-client';

declare const nativeUnixPeerIdentity: CovenUnixPeerIdentityAdapter;
declare const trustedCovenPath: string;
const coven = await createDiscoveredCovenClient({
  discovery: {
    dependencies: {
      resolveExecutable: () => trustedCovenPath,
    },
  },
  transportSecurity: {
    platform: 'unix',
    peerIdentity: nativeUnixPeerIdentity,
  },
});

await coven.health({ timeoutMs: 5_000 });
```

The SDK intentionally does not bundle a peer-credential implementation.
The embedding CLI or runtime must inject a reviewed native provider for its
current platform. There is no pathname-only approximation, shell or `lsof`
fallback, private Node-internals fallback, or permissive default.
OpenCoven's Node CLI likewise ships no implicit adapter: it reports
`platform_security_unavailable` and marks Coven health unhealthy until the
embedding runtime injects a reviewed native provider. It never derives
connected-peer or connected-pipe identity from discovery metadata, filesystem
ownership, or shell commands.

`discoverCovenEndpoint()` can inspect the typed endpoint and its available
owner/freshness metadata. Unix `COVEN_HOME` discovery needs no executable
resolver; CLI-based and all Windows discovery must inject the trusted
executable collaborators described above:

```ts
const endpoint = await discoverCovenEndpoint({
  dependencies: {
    resolveExecutable: () => trustedCovenPath,
  },
});
```

## Same-user IPC

The built-in health transports support only `GET /api/v1/health` for the exact
`coven.daemon.v1` protocol. They do not expose arbitrary request methods,
frames, or socket handles.

- Unix endpoints must be normalized absolute paths. The transport uses
  `lstat`, rejects symlinks and non-sockets, requires the current effective UID
  and rejects group/world-writable modes. Because Node has no portable API for
  connected Unix peer identity, callers must provide a native
  `peerIdentity.inspectConnected(socket)` adapter through a discriminated
  `{ platform: 'unix' }` security provider. The adapter receives the exact live
  connected socket, not its pathname, and must derive the peer credentials
  from that socket. It returns the actual peer `uid` with optional `gid` and
  `pid`; filesystem device/inode values are not peer credentials. The
  transport requires the peer UID to equal the current effective UID, then
  separately re-runs `lstat` and requires the pathname's device, inode, socket
  type, owner, and mode to match the pre-connect snapshot. Adapter errors,
  identity mismatch, and validation timeout fail closed.
- Windows endpoints must be canonical local `\\.\pipe\...` names. Node does
  not expose sufficient named-pipe ACL/owner inspection, so Windows callers
  must provide a native, PowerShell-free `ownership` adapter through a
  discriminated `{ platform: 'windows' }` security provider. The adapter
  validates the current owner before connection and the connected pipe
  identity afterward.

Direct transport construction uses the same discriminated security providers
as discovered clients:

```ts
import {
  createCovenUnixTransport,
  createCovenWindowsTransport,
  type CovenDiscoveredEndpoint,
  type CovenUnixPeerIdentityAdapter,
  type CovenWindowsPipeOwnershipAdapter,
} from '@opencoven/coven-client';

declare const unixEndpoint: CovenDiscoveredEndpoint;
declare const windowsEndpoint: CovenDiscoveredEndpoint;
declare const nativeUnixPeerIdentity: CovenUnixPeerIdentityAdapter;
declare const nativeWindowsPipeOwnership: CovenWindowsPipeOwnershipAdapter;

const unixTransport = createCovenUnixTransport(unixEndpoint, {
  security: {
    platform: 'unix',
    peerIdentity: nativeUnixPeerIdentity,
  },
});

const windowsTransport = createCovenWindowsTransport(windowsEndpoint, {
  security: {
    platform: 'windows',
    ownership: nativeWindowsPipeOwnership,
  },
});
```

Supplying the wrong platform provider, omitting `security`, using a bare
Windows `ownership` property, or returning unverifiable connected-peer data
is rejected rather than downgraded to pathname validation.

Connect and request timeouts, HTTP headers, response bodies, and framing are
bounded. The health response must contain boolean `sessions`, `events`, and
`structuredErrors` capabilities; `eventCursor` remains optional for source
compatibility. A health operation deadline covers ownership/path inspection,
connected-peer revalidation, connect, write, read, and socket cleanup.
Connected sockets are paused while peer/pipe and pathname validation runs; no
request is written and no response can resolve before validation succeeds.

Optional daemon metadata is first `lstat`-validated as a non-symlink,
owner-safe regular file, then read through a bounded file handle using at most
16 KiB plus one detection byte. Stat, open, read, and close share the discovery
deadline; FIFOs, devices, oversized files, and stalled operations fail closed.

## Errors

Discovery and built-in transport failures use `CovenIpcError` with stable
codes: `not_found`, `command_failed`, `malformed_config`, `unsafe_endpoint`,
`owner_mismatch`, `connect_failure`, `timeout`, `body_limit`, `frame_limit`,
and `invalid_response`. Diagnostics contain only allowlisted scalar metadata,
such as phase, exit status, signal, and byte counts. Command output,
filesystem contents, credentials, and socket handles are never copied into
public errors.

Daemon error envelopes remain structured on `CovenClientError.daemon` instead
of being flattened to strings. `code`, `message`, optional numeric `status`,
and optional `details` are preserved; safe additive fields are ignored. Details
are copied through bounded, cycle- and accessor-safe validation, while
sensitive field names, excessive depth, or excessive structured size fail
closed as `invalid_response`. Branded-error inspection reads only own data
descriptors and never invokes property getters. Use
`isCovenClientError(error)` and `isCovenIpcError(error)` when errors may cross
bundles or duplicate package installations.

`health()` accepts an optional signal, timeout, and lifecycle observer.
Constructor operation defaults remain additive, and zero-argument transports
remain compatible. There is no default timeout and no automatic retry. Timeout
rejects promptly for non-cooperative transports, while stopping underlying
daemon I/O requires the transport to honor its context signal. Retry transient
`not_found`, `command_failed`, `connect_failure`, or `timeout` failures only
after the operator has started or repaired the local runtime; ownership,
endpoint safety, malformed config, and platform-security failures are
fail-closed configuration issues.

The owner-local Coven daemon contract does not use bearer tokens, API keys,
cookies, or credential files. This package neither discovers nor sends them.

## License

AGPL-3.0-only OR MIT. See [LICENSE](LICENSE).
